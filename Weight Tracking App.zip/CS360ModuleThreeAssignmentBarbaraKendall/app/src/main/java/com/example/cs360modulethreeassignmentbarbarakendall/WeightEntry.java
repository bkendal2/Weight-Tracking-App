package com.example.cs360modulethreeassignmentbarbarakendall;

public class WeightEntry {
    public long id;
    public String date;
    public double weight;
    public String note;

    public WeightEntry(long id, String date, double weight, String note) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.note = note;
    }
}