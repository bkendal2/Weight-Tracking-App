package com.example.cs360modulethreeassignmentbarbarakendall;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    // Database
    private static final String DB_NAME = "cs360_app.db";
    private static final int DB_VERSION = 1;

    // Users table
    public static final String T_USERS = "users";
    public static final String U_ID = "_id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    // Weight entries table
    public static final String T_WEIGHTS = "weight_entries";
    public static final String W_ID = "_id";
    public static final String W_DATE = "entry_date";   // store "YYYY-MM-DD"
    public static final String W_WEIGHT = "weight";     // REAL
    public static final String W_NOTE = "note";         // TEXT optional

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsers = "CREATE TABLE " + T_USERS + " ("
                + U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + U_USERNAME + " TEXT UNIQUE NOT NULL, "
                + U_PASSWORD + " TEXT NOT NULL"
                + ");";

        String createWeights = "CREATE TABLE " + T_WEIGHTS + " ("
                + W_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + W_DATE + " TEXT NOT NULL, "
                + W_WEIGHT + " REAL NOT NULL, "
                + W_NOTE + " TEXT"
                + ");";

        db.execSQL(createUsers);
        db.execSQL(createWeights);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Simple for class project
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_WEIGHTS);
        onCreate(db);
    }

    // -------------------------
    // USERS (LOGIN)
    // -------------------------
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS,
                new String[]{U_ID},
                U_USERNAME + "=?",
                new String[]{username},
                null, null, null);

        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(U_USERNAME, username);
        cv.put(U_PASSWORD, password);
        long result = db.insert(T_USERS, null, cv);
        return result != -1;
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(T_USERS,
                new String[]{U_ID},
                U_USERNAME + "=? AND " + U_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);

        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // -------------------------
    // WEIGHT ENTRIES (CRUD)
    // -------------------------
    public long addWeightEntry(String date, double weight, @Nullable String note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(W_DATE, date);
        cv.put(W_WEIGHT, weight);
        cv.put(W_NOTE, note);
        return db.insert(T_WEIGHTS, null, cv);
    }

    public boolean updateWeightEntry(long id, String date, double weight, @Nullable String note) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(W_DATE, date);
        cv.put(W_WEIGHT, weight);
        cv.put(W_NOTE, note);

        int rows = db.update(T_WEIGHTS, cv, W_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean deleteWeightEntry(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(T_WEIGHTS, W_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public List<WeightEntry> getAllWeightEntries() {
        List<WeightEntry> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(T_WEIGHTS,
                new String[]{W_ID, W_DATE, W_WEIGHT, W_NOTE},
                null, null, null, null,
                W_ID + " DESC");

        while (c.moveToNext()) {
            long id = c.getLong(c.getColumnIndexOrThrow(W_ID));
            String date = c.getString(c.getColumnIndexOrThrow(W_DATE));
            double weight = c.getDouble(c.getColumnIndexOrThrow(W_WEIGHT));
            String note = c.getString(c.getColumnIndexOrThrow(W_NOTE));

            list.add(new WeightEntry(id, date, weight, note));
        }
        c.close();
        return list;
    }
}
