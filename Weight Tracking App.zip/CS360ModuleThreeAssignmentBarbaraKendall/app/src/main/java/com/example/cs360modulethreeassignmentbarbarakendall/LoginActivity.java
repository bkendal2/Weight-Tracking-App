package com.example.cs360modulethreeassignmentbarbarakendall;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private DBHelper db;
    private EditText etUsername, etPassword;
    private Button btnLogin, btnCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DBHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnCreateAccount = findViewById(R.id.btnCreateAccount);

        btnCreateAccount.setOnClickListener(v -> handleCreateAccount());
        btnLogin.setOnClickListener(v -> handleLogin());
    }

    private void handleCreateAccount() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.userExists(username)) {
            Toast.makeText(this, "That username already exists. Try logging in.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean created = db.createUser(username, password);
        if (created) {
            Toast.makeText(this, "Account created! You can log in now.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Could not create account. Try a different username.", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter your username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean ok = db.validateLogin(username, password);
        if (ok) {
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("username", username);
            startActivity(i);
            finish();
        } else {
            Toast.makeText(this, "Login failed. Create an account if you're new.", Toast.LENGTH_SHORT).show();
        }
    }
}