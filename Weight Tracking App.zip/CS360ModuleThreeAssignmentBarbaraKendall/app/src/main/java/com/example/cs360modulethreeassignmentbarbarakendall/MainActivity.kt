package com.example.cs360modulethreeassignmentbarbarakendall;

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.text.TextUtils
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), WeightAdapter.Listener {

    private lateinit var db: DBHelper
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: WeightAdapter
    private val data: MutableList<WeightEntry> = ArrayList()

    private lateinit var btnAdd: Button
    private lateinit var btnRequestSms: Button
    private lateinit var btnTestSms: Button

    private val GOAL_WEIGHT = 120.0

    private val smsPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(
                    this,
                    "SMS permission denied. App will still work without SMS.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DBHelper(this)

        recyclerView = findViewById(R.id.recyclerView)
        btnAdd = findViewById(R.id.btnAdd)
        btnRequestSms = findViewById(R.id.btnRequestSms)
        btnTestSms = findViewById(R.id.btnTestSms)

        recyclerView.layoutManager = GridLayoutManager(this, 2)
        adapter = WeightAdapter(data, this)
        recyclerView.adapter = adapter

        btnAdd.setOnClickListener { showAddEditDialog(null) }
        btnRequestSms.setOnClickListener { requestSmsPermission() }
        btnTestSms.setOnClickListener {
            if (hasSmsPermission()) {
                sendSms("+15555551234", "Test alert from CS360 app (permission granted).")
            } else {
                Toast.makeText(this, "SMS permission not granted. Tap 'Enable SMS' first.", Toast.LENGTH_SHORT).show()
            }
        }

        loadData()
    }

    private fun loadData() {
        data.clear()
        data.addAll(db.getAllWeightEntries())
        adapter.notifyDataSetChanged()
    }

    private fun requestSmsPermission() {
        if (hasSmsPermission()) {
            Toast.makeText(this, "SMS permission is already granted.", Toast.LENGTH_SHORT).show()
            return
        }
        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
    }

    private fun hasSmsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED
    }

    private fun sendSms(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(this, "SMS sent.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onEdit(entry: WeightEntry) {
        showAddEditDialog(entry)
    }

    override fun onDelete(entry: WeightEntry) {
        val ok = db.deleteWeightEntry(entry.id)
        if (ok) {
            Toast.makeText(this, "Deleted.", Toast.LENGTH_SHORT).show()
            loadData()
        } else {
            Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAddEditDialog(existing: WeightEntry?) {
        val isEdit = existing != null

        val view = LayoutInflater.from(this).inflate(R.layout.dialog_add_edit_weight, null)
        val etDate = view.findViewById<EditText>(R.id.etDate)
        val etWeight = view.findViewById<EditText>(R.id.etWeight)
        val etNote = view.findViewById<EditText>(R.id.etNote)

        if (isEdit) {
            etDate.setText(existing!!.date)
            etWeight.setText(existing.weight.toString())
            etNote.setText(existing.note ?: "")
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle(if (isEdit) "Edit Entry" else "Add Entry")
            .setView(view)
            .setPositiveButton(if (isEdit) "Update" else "Add", null)
            .setNegativeButton("Cancel") { d, _ -> d.dismiss() }
            .create()

        dialog.setOnShowListener {
            val positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            positive.setOnClickListener {
                val date = etDate.text.toString().trim()
                val weightStr = etWeight.text.toString().trim()
                val note = etNote.text.toString().trim()

                if (TextUtils.isEmpty(date) || TextUtils.isEmpty(weightStr)) {
                    Toast.makeText(this, "Date and weight are required.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val weightVal = try {
                    weightStr.toDouble()
                } catch (ex: NumberFormatException) {
                    Toast.makeText(this, "Enter a valid number for weight.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val ok = if (isEdit) {
                    db.updateWeightEntry(existing!!.id, date, weightVal, note)
                } else {
                    db.addWeightEntry(date, weightVal, note) != -1L
                }

                if (ok) {
                    loadData()
                    dialog.dismiss()

                    // Trigger: goal reached
                    if (weightVal <= GOAL_WEIGHT) {
                        if (hasSmsPermission()) {
                            sendSms("+15555551234", "Congrats! You reached your goal weight: $weightVal")
                        } else {
                            Toast.makeText(this, "Goal reached! Enable SMS if you want text alerts.", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    Toast.makeText(this, "Save failed.", Toast.LENGTH_SHORT).show()
                }
            }
        }

        dialog.show()
    }
}
